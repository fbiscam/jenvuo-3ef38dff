JENVU EA - INSTALL GUIDE (jenvu.com)
=====================================

STEP 1 - GET YOUR LICENSE KEY
  1. Sign in at https://jenvu.com and open your Dashboard.
  2. Enter your MT5 account number (digits only, e.g. 12345678).
     Find it in MT5: Navigator > Accounts, or File > Login to Trade Account.
     Do NOT enter your password, email or license key here.
  3. Copy your key. It looks like: JENV-XXXX-XXXX-XXXX-XXXX
     The key works only on that one MT5 account.

STEP 2 - INSTALL THE EA
  1. MT5: File > Open Data Folder > MQL5 > Experts.
     Paste "Jenvu EA.ex5" from the "Jenvu EA" folder.
  2. Open MQL5 > Presets and paste the .set files from "Presets".
  3. Navigator > Expert Advisors > right click > Refresh.

STEP 3 - ALLOW THE LICENSE CHECK (very important)
  1. Tools > Options > Expert Advisors.
  2. Tick "Allow WebRequest for listed URL".
  3. Click "Add new" and type:  https://jenvu.com
  4. Click OK.

STEP 4 - RUN THE EA
  1. Turn on "Algo Trading" in the top toolbar.
  2. Open the XAUUSD M15 chart.
  3. Drag "Jenvu EA" onto the chart.
  4. Inputs tab: click Load > choose "Jenvu Xau M15 Exness.set".
  5. Paste your key into LicenseKey. Leave LicenseUrl as it is.
  6. Press OK. The Experts tab should show "Jenvu license: VALID".

IF THE LICENSE SHOWS INVALID
  - "server not reachable"  : Step 3 is missing. Add https://jenvu.com.
  - "different MT5 account" : The key was made for another account number.
                              Make a new key for the account you are logged in to.
  - "expired"               : Renew your plan at jenvu.com.
  - "not recognised"        : Copy the key again from the dashboard (no spaces).

JENVU PLANS & DAILY PROFIT TARGET
  Plan     Monthly profit target   Daily target   Licenses (MT5 accounts)
  Pro      $1,000                  $50            1
  Elite    $3,000                  $150           2
  Ultra    $6,000                  $300           5
  Daily target = monthly target / 20 trading days.
  When today's profit (closed + floating) reaches the daily target, the EA
  closes all trades and pauses. It starts again automatically the next day.
  The target comes from your license, so no setting is needed.

ON-CHART PANEL
  The info panel on the chart has a white background with Poppins-style text.
  For the exact look, install the free Poppins font on your PC:
  https://fonts.google.com/specimen/Poppins  (Download, right click the font
  files > Install, then restart MT5.) Without it, Windows shows its standard
  font and the panel still works the same.

  If the panel covers the BUY/SELL buttons, open the EA inputs (F7 on the
  chart) and increase "Panel distance from chart top" (default 130 pixels).
  Set it to 20 to move the panel back near the top.


Test on a demo account first. Trading involves risk.
Support: https://jenvu.com
